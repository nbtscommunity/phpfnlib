__revision__ = '$Id: __init__.py,v 1.5 2002/09/23 07:59:16 syt Exp $'

modname = 'xmldiff'

numversion = (0,6,2)
version = '.'.join(map(str, numversion))
